from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name = 'menu-home'),
    path('home', views.home, name = 'menu-home'),
    path('about', views.about, name = 'menu-about'),
    path('details', views.details, name = 'menu-details')
]
