from django.shortcuts import render

# Create your views here.
context = [
            {'name':'Lurdes Dias', 'day':2},
            {'name':'Patrcia Julia', 'day':20},
            {'name':'Angelia Frasão', 'day': 19},
            {'name':'Guilhermina Matias', 'day':31}
        ]

def home(request):
    listnames = {'names': context}
    return render(request, 'blog/home.html',listnames)


def about(request):
    return render(request, 'blog/about.html')


def details(request):
    return render(request, 'blog/details.html')

